package example;

public class Singleton {

    private static Singleton singletonInstance = null;
    private Singleton(){}

    public static Singleton getInstance(){
        if(singletonInstance == null){
            singletonInstance = new Singleton();
        }
        return singletonInstance;
    }

    public void setNome(String name){
        //Metodo dummy1
    }
    public void setCorso(String corso){
        //Metodo dummy2
    }
}
