package example;



import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {
    private static Logger logger=Logger.getLogger(Main.class.getName());

    public static void main(String[] args) {
        Singleton professore1 = Singleton.getInstance();
        Singleton professore2 = Singleton.getInstance();

        if(professore1 == professore2){
            logger.log(Level.INFO,  "Ho bisogno di un solo professore per corso");
            professore1.setNome("Antonello");
            professore1.setCorso("Analisi 1");
        }
        else{

            logger.log(Level.INFO, "Ho due professori diversi");
        }
    }
}
